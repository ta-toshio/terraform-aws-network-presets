// Lambda関数本体
const AWS = require('aws-sdk');
const ecs = new AWS.ECS();
const ec2 = new AWS.EC2();
const route53 = new AWS.Route53();

exports.handler = async (event) => {
  const { HOSTED_ZONE_ID, DOMAIN_NAME, CLUSTER_NAME, SERVICE_NAME } = process.env;
  
  console.log('Starting Route53 updater for ECS task');
  console.log('Environment:', { HOSTED_ZONE_ID, DOMAIN_NAME, CLUSTER_NAME, SERVICE_NAME });
  
  try {
    // タスクリストを取得
    console.log(`Getting tasks for service ${SERVICE_NAME} in cluster ${CLUSTER_NAME}`);
    const tasks = await ecs.listTasks({
      cluster: CLUSTER_NAME,
      serviceName: SERVICE_NAME,
      desiredStatus: 'RUNNING'
    }).promise();
    
    if (!tasks.taskArns || tasks.taskArns.length === 0) {
      console.log('No running tasks found');
      return { status: 'error', message: 'No running tasks found' };
    }
    
    console.log(`Found ${tasks.taskArns.length} running tasks`);
    
    // タスクの詳細を取得
    const taskDetails = await ecs.describeTasks({
      cluster: CLUSTER_NAME,
      tasks: [tasks.taskArns[0]]
    }).promise();
    
    const task = taskDetails.tasks[0];
    if (!task || !task.attachments || task.attachments.length === 0) {
      console.log('No network attachments found for task');
      return { status: 'error', message: 'No network attachments found' };
    }
    
    // ネットワークインターフェースIDを取得
    const eniDetails = task.attachments[0].details;
    const eniDetail = eniDetails.find(detail => detail.name === 'networkInterfaceId');
    
    if (!eniDetail) {
      console.log('Network interface ID not found');
      return { status: 'error', message: 'Network interface ID not found' };
    }
    
    const eniId = eniDetail.value;
    console.log(`Found ENI ID: ${eniId}`);
    
    // ネットワークインターフェースからパブリックIPを取得
    const eniResponse = await ec2.describeNetworkInterfaces({
      NetworkInterfaceIds: [eniId]
    }).promise();
    
    if (!eniResponse.NetworkInterfaces || !eniResponse.NetworkInterfaces[0].Association) {
      console.log('No public IP associated with ENI');
      return { status: 'error', message: 'No public IP found' };
    }
    
    const publicIp = eniResponse.NetworkInterfaces[0].Association.PublicIp;
    console.log(`Found public IP: ${publicIp}`);
    
    // Route53のレコードを更新
    console.log(`Updating Route53 record for ${DOMAIN_NAME} to ${publicIp}`);
    const result = await route53.changeResourceRecordSets({
      HostedZoneId: HOSTED_ZONE_ID,
      ChangeBatch: {
        Changes: [
          {
            Action: 'UPSERT',
            ResourceRecordSet: {
              Name: DOMAIN_NAME,
              Type: 'A',
              TTL: 60,
              ResourceRecords: [{ Value: publicIp }]
            }
          }
        ]
      }
    }).promise();
    
    console.log('Route53 record updated successfully');
    return { status: 'success', publicIp, recordUpdated: true };
  } catch (error) {
    console.error('Error:', error);
    return { status: 'error', message: error.message };
  }
};
